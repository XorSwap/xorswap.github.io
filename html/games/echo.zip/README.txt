
~ ECHO ~

CONTROLS
Arrow keys - Look & move
Space - Send an echo in the direction you are facing
R - Restart the level
Q - Go back a level (don't go back past 0!)
W - Go forward a level

ECHOES
You can press space to send out an echo.  The screen
will flash once when the echo is sent, and again when
the echo hits a wall.  If the second echo hits the
exit, the screen will flash red instead of white.

When you beat the final level, you'll get a nice light
show, and the game will close itself.
