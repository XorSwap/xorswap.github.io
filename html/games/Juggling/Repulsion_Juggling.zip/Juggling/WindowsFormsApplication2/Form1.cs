﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        bool lalala = false;
        Bitmap swirl = new Bitmap(typeof(Form1), "swirl II.PNG");
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics gr = e.Graphics;
            if (lalala)
                gr.DrawImage(swirl, 10, 10);
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.X > 100)
                lalala = true;
            else
                lalala = false;
            Invalidate();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {

        }
    }
}
