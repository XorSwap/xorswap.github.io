<?php

//Edit the following to adjust the MySql connection.

$connect_url = "localhost";
$connect_database = "forum2";
$connect_user = "root";
$connect_password = "incorrect";

?>
