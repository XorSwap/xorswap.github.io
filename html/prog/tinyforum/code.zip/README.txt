Installation instructions:
execute the following command:

mysql < install.sql

You may need to add some flags to mysql in order to get it to run.
Other than that, you simply need to visit index.php in a web browser to see the forum in action.
