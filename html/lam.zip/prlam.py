primes = list("`/b`b`b``/c`cc/c/d/e``e/f/gg`/f```ccf`/g`gg/g`f`gg/f/g/h/i``ig`h`df/c/d/e`b`ec/b/c``c/d/edb");
primes.reverse();
st = [];
i = 0;
while i < len(primes):
	if primes[i] == "`":
		st.append("Apply(" + st.pop() + "," + st.pop() + ")");
	elif primes[i + 1] == "/":
		st.append("Lambda('" + primes[i] + "'," + st.pop() + ")")
		i += 1;
	else:
		st.append("Id('" + primes[i] + "')");
	i += 1;
print st[0];