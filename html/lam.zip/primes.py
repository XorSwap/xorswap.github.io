def conv(tree):
	if type(tree) is list:
		return reduce(lambda a,b: [a,b],map(conv,tree));
	return tree;
def pr(tree):
	if type(tree) is list:
		return "(app(" + pr(tree[0]) + ")(" + pr(tree[1]) + "))";
	return tree;
prog = ["S","I",["S","I",["S",["K",["S","I","I",["S",["K",["S",["K",["S",["S","I",["K",["K","I"]]]]]]],["S",["K",["S",["K","K"]]],["S",["S",["K","S"],["S",["K","K"],["S",["S",["K","S"],["S","I","I"]],["K",["S",["K",["S","I","I"]],["S",["S",["K","S"],"K"],["K",["S","I","I"]]]]]]]],["K",["S",["K",["S",["K",["S",["S",["K","S"],["S",["K","K"],["S",["K","S"],["S",["K",["S","I"]],"K"]]]]]]]],["S",["K",["S",["K","K"]]],["S",["K",["S",["K",["S",["K","K"]]]]],["S",["K",["S",["K",["S","I"]]]],["S",["K","K"]]]]]]]]]]]],["S",["K",["S",["K","K"]]],["S",["S",["K","S"],["S",["K","K"],["S",["K","S"],"K"]]],["K",["S",["K",["S","I"]],"K"]]]]]],["S",["K",["S",["S","I",["K","K"]]]],"K"]]
print pr(conv(prog))