import sys;
app = lambda a:lambda b:lambda:a()(b)
S = lambda:lambda x:lambda y:lambda z:x()(z)(lambda:y()(z))
K = lambda:lambda x:lambda y:x()
I = app(app(S)(K))(K)
sys.setrecursionlimit(99999999);
t = lambda:(lambda b: (b()(lambda: (b()(lambda: ((lambda c: c()(c))(lambda: (lambda c: (lambda d: (lambda e: ((e()(lambda: (lambda f: (lambda g: ((g)())))))(lambda: ((lambda f: (c()(c)(f)(lambda: ((lambda g: g()(g))(lambda: (lambda g: (((f)())(lambda: (g()(g))))))))))(lambda: lambda f: lambda g: lambda h: lambda i: i()(g)(lambda: h()(lambda: d()(f)))))))))))(lambda: lambda c: lambda d: lambda e: b()(lambda: e()(c)))))))))(lambda: lambda b: lambda c: c()(lambda: lambda d: lambda e: d())(b))
while True:
	h = app(t)(K)
	sys.stdout.write(app(app(h)(lambda:'0'))(lambda:'1')())
	t = app(t)(app(K)(I))
	q = t()
	t = lambda:q