app = lambda a: lambda b: lambda: a()(b);
S = lambda: lambda x: lambda y: lambda z: x()(z)(lambda: y()(z));
K = lambda: lambda x: lambda y: x();
I = app(app(S)(K))(K)
def tonum(f):
	return app(app(f)(lambda n: n + 1))(0);
def run(f):
	import sys;
	compose = lambda f,x,n: reduce(lambda x,_: f(x),xrange(n),x);
	zero = lambda: lambda f: lambda x: x();
	succ = lambda: lambda n: lambda f: lambda x: f()(lambda: n()(f)(x));
	getchar = lambda: compose(succ,zero,ord(sys.stdin.read(1)));
	input = lambda: (lambda f: f()(f))(lambda: lambda f: lambda b: b()(getchar)(lambda: f()(f)));
	head = K
	tail = app(K)(I)
	
	while True:
		f = f()(input);
		c = app(tonum)(app(f)(head));
		#if c >= 256:
		#	break;
		sys.stdout.write(chr(c));
		f = app(f)(tail);
#run(I);

#primes = (app((app((app(S)(I)))((app((app(S)(I)))((app((app(S)((app(K)((app((app((app(S)(I)))(I)))((app((app(S)((app(K)((app(S)((app(K)((app(S)((app((app(S)(I)))((app(K)((app(K)(I)))))))))))))))))((app((app(S)((app(K)((app(S)((app(K)(K)))))))))((app((app(S)((app((app(S)((app(K)(S)))))((app((app(S)((app(K)(K)))))((app((app(S)((app((app(S)((app(K)(S)))))((app((app(S)(I)))(I)))))))((app(K)((app((app(S)((app(K)((app((app(S)(I)))(I)))))))((app((app(S)((app((app(S)((app(K)(S)))))(K)))))((app(K)((app((app(S)(I)))(I)))))))))))))))))))((app(K)((app((app(S)((app(K)((app(S)((app(K)((app(S)((app((app(S)((app(K)(S)))))((app((app(S)((app(K)(K)))))((app((app(S)((app(K)(S)))))((app((app(S)((app(K)((app(S)(I)))))))(K)))))))))))))))))))((app((app(S)((app(K)((app(S)((app(K)(K)))))))))((app((app(S)((app(K)((app(S)((app(K)((app(S)((app(K)(K)))))))))))))((app((app(S)((app(K)((app(S)((app(K)((app(S)(I)))))))))))((app(S)((app(K)(K)))))))))))))))))))))))))))((app((app(S)((app(K)((app(S)((app(K)(K)))))))))((app((app(S)((app((app(S)((app(K)(S)))))((app((app(S)((app(K)(K)))))((app((app(S)((app(K)(S)))))(K)))))))))((app(K)((app((app(S)((app(K)((app(S)(I)))))))(K)))))))))))))))((app((app(S)((app(K)((app(S)((app((app(S)(I)))((app(K)(K)))))))))))(K))));






















import sys;
primes = lambda:(lambda b: (b()(lambda: (b()(lambda: ((lambda c: c()(c))(lambda: (lambda c: (lambda d: (lambda e: ((e()(lambda: (lambda f: (lambda g: ((g)())))))(lambda: ((lambda f: (c()(c)(f)(lambda: ((lambda g: g()(g))(lambda: (lambda g: (((f)())(lambda: (g()(g))))))))))(lambda: lambda f: lambda g: lambda h: lambda i: i()(g)(lambda: h()(lambda: d()(f)))))))))))(lambda: lambda c: lambda d: lambda e: b()(lambda: e()(c)))))))))(lambda: lambda b: lambda c: c()(lambda: lambda d: lambda e: d())(b));

sys.setrecursionlimit(99999999);
t = primes;
while True:
	h = app(t)(K);#head
	sys.stdout.write(app(app(h)(lambda:'0'))(lambda:'1')())
	t = app(t)(app(K)(I));#tail
	q = t();#speed it up a bit with some eager eval
	t = lambda: q;