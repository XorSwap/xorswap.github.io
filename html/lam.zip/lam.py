#def lazy(val):
#	return "(lambda: " + val + ")";
#def force(val):
#	return "(" + val + "())";
#def lam(var,val):
#	return "(lambda " + var + ": " + val + ")";
#def app(a,b):
#	return "(" + a + " " + b + ")";

#def lazy(val):
#	return "(lazy " + val + ")";
#def force(val):
#	return "(force " + val + ")";
#def lam(var,val):
#	return "(lambda " + var + " " + val + ")";
#def app(a,b):
#	return "(apply " + a + " " + b + ")";
def lazy(val):
	return ["lazy",val];
def force(val):
	return ["force",val];
def lam(var,val):
	return ["lambda",var,val];
def app(a,b):
	return ["apply",a,b];
def id(var):
	return ["id",var];
def optimize(tree):
	if tree[0] == "id":
		return tree;
	if tree[0] == "force" and tree[1][0] == "lazy":
		return optimize(tree[1][1]);
	if tree[0] == "lambda":
		tree[2] = optimize(tree[2]);
		return tree;
	return [tree[0]] + map(optimize,tree[1:]);
def topy(tree):
	#return str(tree);
	ops = {
		"id":		lambda var:		var,
		"lazy":		lambda var:		"lambda: " + topy(var),
		"force":	lambda var:		topy(var) + "()",
		"lambda":	lambda var,val:	"lambda " + var[0] + ": " + topy(val),
		"apply":	lambda a,b:		topy(a) + topy(b),
	};
	return "(" + ops[tree[0]](*tree[1:]) + ")";
def pr(tree):
	if type(tree) is list:
		return "(" + " ".join(map(pr,tree)) + ")";
	return tree;
	if tree[0] == "id":
		return tree;
def eval(string):
	exec "_="+string;
	return _;
class Lambda:
	def __init__(this,var,val):
		this.var = var;
		this.val = val;
	def conv(this):
		return lazy(lam(this.var,force(this.val.conv())));
class Apply:
	def __init__(this,a,b):
		this.a = a;
		this.b = b;
	def conv(this):
		return lazy(app(force(this.a.conv()),this.b.conv()));
class Id:
	def __init__(this,val):
		this.val = val;
	def conv(this):
		return id(this.val);

#prog = Apply(Lambda("f",Apply(Id("f"),Id("f"))),Lambda("f",Apply(Id("f"),Id("f"))));
#prog = Lambda("x",Lambda("y",Lambda("z",Apply(Apply(Id("x"),Id("z")),Apply(Id("y"),Id("z"))))))
#prog = Lambda("x",Lambda("y",Id("x")));
#prog = Apply(Lambda("f",Apply(Id("f"),Id("f"))),Lambda("f",Lambda("b", Apply(Apply(Id("b"),Id("A")),Apply(Id("f"),Id("f"))) )))
#prog = Lambda("f",Lambda("x",Id("x")))
#prog = Lambda("n",Lambda("f",Lambda("x",Apply(Id("f"),Apply(Apply(Id("n"),Id("f")),Id("x"))))))
#prog = Lambda("f",Id("f"));
prog = Apply(Lambda('b',Apply(Id('b'),Apply(Id('b'),Apply(Apply(Lambda('c',Apply(Id('c'),Id('c'))),Lambda('c',Lambda('d',Lambda('e',Apply(Apply(Id('e'),Lambda('f',Lambda('g',Id('g')))),Apply(Lambda('f',Apply(Apply(Apply(Id('c'),Id('c')),Id('f')),Apply(Lambda('g',Apply(Id('g'),Id('g'))),Lambda('g',Apply(Id('f'),Apply(Id('g'),Id('g'))))))),Lambda('f',Lambda('g',Lambda('h',Lambda('i',Apply(Apply(Id('i'),Id('g')),Apply(Id('h'),Apply(Id('d'),Id('f')))))))))))))),Lambda('c',Lambda('d',Lambda('e',Apply(Id('b'),Apply(Id('e'),Id('c')))))))))),Lambda('b',Lambda('c',Apply(Apply(Id('c'),Lambda('d',Lambda('e',Id('d')))),Id('b')))));
prog = prog.conv();
prog = optimize(prog);
prog = topy(prog);
#prog = eval(prog);
#prog = __import__('dis').dis(prog);
#prog = pr(prog);
print prog;